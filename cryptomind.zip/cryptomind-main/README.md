# cryptomind 
## npm run start to star the app